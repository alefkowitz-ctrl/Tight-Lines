import { useState, useRef, useEffect, useCallback } from "react";

// ─── API helpers ──────────────────────────────────────────────────────────────
const ANTHROPIC_KEY = import.meta.env.VITE_ANTHROPIC_KEY || "";

async function askClaude(prompt, useSearch = false, maxTokens = 1200) {
  const body = {
    model: "claude-sonnet-4-20250514",
    max_tokens: maxTokens,
    messages: [{ role: "user", content: prompt }],
  };
  if (useSearch) body.tools = [{ type: "web_search_20250305", name: "web_search" }];
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify(body),
  });
  const d = await res.json();
  if (d.error) throw new Error(d.error.message);
  return (d.content || []).map(b => b.text || "").filter(Boolean).join("");
}

async function geocode(query) {
  const res = await fetch(
    `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=6&countrycodes=us&addressdetails=1`,
    { headers: { "Accept-Language": "en" } }
  );
  return res.json();
}

async function reverseGeocode(lat, lng) {
  const res = await fetch(
    `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`,
    { headers: { "Accept-Language": "en" } }
  );
  return res.json();
}

async function fetchWeather(lat, lng) {
  const res = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}` +
    `&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,surface_pressure,uv_index` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min` +
    `&temperature_unit=fahrenheit&wind_speed_unit=mph&timezone=auto&forecast_days=7`
  );
  return res.json();
}

async function fetchUSGSLive(lat, lng) {
  const pad = 0.8;
  const bbox = `${lng - pad},${lat - pad},${lng + pad},${lat + pad}`;
  const res = await fetch(
    `https://waterservices.usgs.gov/nwis/iv/?format=json&bBox=${bbox}&parameterCd=00060&siteType=ST&siteStatus=active`
  );
  return res.json();
}

async function fetchUSGSHistory(lat, lng) {
  const pad = 0.8;
  const bbox = `${lng - pad},${lat - pad},${lng + pad},${lat + pad}`;
  const end = new Date(), start = new Date();
  start.setDate(end.getDate() - 30);
  const fmt = d => d.toISOString().split("T")[0];
  const res = await fetch(
    `https://waterservices.usgs.gov/nwis/dv/?format=json&bBox=${bbox}&parameterCd=00060&siteType=ST&siteStatus=active&startDT=${fmt(start)}&endDT=${fmt(end)}`
  );
  return res.json();
}

function extractJSON(text) {
  const clean = text.replace(/```json|```/g, "").trim();
  try { const m = clean.match(/\{[\s\S]*\}/); if (m) return JSON.parse(m[0]); } catch {}
  try { const m = clean.match(/\[[\s\S]*\]/); if (m) return JSON.parse(m[0]); } catch {}
  return null;
}

// ─── Constants ────────────────────────────────────────────────────────────────
const MONTHLY_HATCHES = {
  0:[{name:"Midge",activity:"Heavy"},{name:"Blue Winged Olive",activity:"Light"}],
  1:[{name:"Midge",activity:"Heavy"},{name:"Blue Winged Olive",activity:"Light"}],
  2:[{name:"Midge",activity:"Moderate"},{name:"Blue Winged Olive",activity:"Moderate"},{name:"Skwala Stonefly",activity:"Early"}],
  3:[{name:"Blue Winged Olive",activity:"Heavy"},{name:"Skwala Stonefly",activity:"Moderate"},{name:"March Brown",activity:"Light"}],
  4:[{name:"Pale Morning Dun",activity:"Heavy"},{name:"Caddis",activity:"Moderate"},{name:"Green Drake",activity:"Early"}],
  5:[{name:"Green Drake",activity:"Heavy"},{name:"Pale Morning Dun",activity:"Heavy"},{name:"Salmonfly",activity:"Moderate"},{name:"Caddis",activity:"Heavy"}],
  6:[{name:"Caddis",activity:"Heavy"},{name:"Pale Morning Dun",activity:"Moderate"},{name:"Yellow Sally",activity:"Moderate"},{name:"Trico",activity:"Early"}],
  7:[{name:"Trico",activity:"Heavy"},{name:"Caddis",activity:"Moderate"},{name:"Hopper",activity:"Heavy"},{name:"Yellow Sally",activity:"Light"}],
  8:[{name:"Hopper",activity:"Heavy"},{name:"Trico",activity:"Moderate"},{name:"Blue Winged Olive",activity:"Early"},{name:"Caddis",activity:"Light"}],
  9:[{name:"Blue Winged Olive",activity:"Heavy"},{name:"Hopper",activity:"Moderate"},{name:"Mahogany Dun",activity:"Moderate"}],
  10:[{name:"Blue Winged Olive",activity:"Heavy"},{name:"Midge",activity:"Moderate"},{name:"Mahogany Dun",activity:"Light"}],
  11:[{name:"Midge",activity:"Heavy"},{name:"Blue Winged Olive",activity:"Light"}],
};

const WX_EMOJI = {0:"☀️",1:"🌤",2:"⛅",3:"☁️",45:"🌫",48:"🌫",51:"🌦",53:"🌦",55:"🌧",61:"🌧",63:"🌧",65:"🌧",71:"🌨",73:"🌨",75:"❄️",80:"🌦",81:"🌧",95:"⛈",96:"⛈",99:"⛈"};
const WX_DESC = {0:"Clear",1:"Mainly Clear",2:"Partly Cloudy",3:"Overcast",45:"Fog",48:"Freezing Fog",51:"Light Drizzle",53:"Drizzle",55:"Heavy Drizzle",61:"Light Rain",63:"Rain",65:"Heavy Rain",71:"Light Snow",73:"Snow",75:"Heavy Snow",80:"Showers",81:"Heavy Showers",95:"Thunderstorm",96:"Hail",99:"Severe Storm"};
const DAY_NAMES = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const SPECIES = ["Brown Trout","Rainbow Trout","Brook Trout","Cutthroat Trout","Lake Trout","Bull Trout","Steelhead","Largemouth Bass","Smallmouth Bass","Other"];

function cfsLabel(cfs) {
  if (!cfs || isNaN(cfs)) return { label:"No Data", cls:"fair" };
  if (cfs < 50)   return { label:"Very Low",   cls:"low" };
  if (cfs < 200)  return { label:"Low",        cls:"low" };
  if (cfs < 800)  return { label:"Good",       cls:"good" };
  if (cfs < 2000) return { label:"High",       cls:"fair" };
  return               { label:"Flood Risk",  cls:"high" };
}

function fmtCoord(lat, lng) {
  return `${Math.abs(lat).toFixed(4)}°${lat >= 0 ? "N" : "S"}, ${Math.abs(lng).toFixed(4)}°${lng >= 0 ? "E" : "W"}`;
}

function cleanLocationLabel(item) {
  const a = item.address || {};
  const name = a.river || a.stream || a.waterway || a.city || a.town || a.village || a.county || item.display_name.split(",")[0];
  const state = a.state || "";
  return state ? `${name}, ${state}` : name;
}

function locationIcon(item) {
  const t = (item.type || item.class || "").toLowerCase();
  if (["river","stream","waterway"].some(x => t.includes(x))) return "🏞";
  if (["city","town","village","municipality"].some(x => t.includes(x))) return "🏙";
  if (["park","forest","nature_reserve"].some(x => t.includes(x))) return "🌲";
  return "📍";
}

// ─── SVG Flow Chart ───────────────────────────────────────────────────────────
function FlowChart({ points, label }) {
  if (!points || points.length < 2) return null;
  const W=340, H=100, PL=42, PR=8, PT=8, PB=24;
  const iW=W-PL-PR, iH=H-PT-PB;
  const vals = points.map(p => p.v);
  const minV = Math.min(...vals), maxV = Math.max(...vals), range = maxV - minV || 1;
  const px = i => PL + (i / (points.length - 1)) * iW;
  const py = v => PT + iH - ((v - minV) / range) * iH;
  const linePts = points.map((p,i) => `${px(i)},${py(p.v)}`).join(" ");
  const areaPts = `${PL},${PT+iH} ` + points.map((p,i) => `${px(i)},${py(p.v)}`).join(" ") + ` ${PL+iW},${PT+iH}`;
  const yTicks = [minV, (minV+maxV)/2, maxV];
  const xIdxs = [0, Math.floor(points.length/2), points.length-1];
  return (
    <div>
      {label && <div style={{fontSize:11,color:"var(--stone)",marginBottom:4,fontStyle:"italic"}}>{label}</div>}
      <svg width={W} height={H} style={{display:"block",maxWidth:"100%"}}>
        <defs>
          <linearGradient id="flowGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#b8d4dc" stopOpacity="0.35"/>
            <stop offset="100%" stopColor="#b8d4dc" stopOpacity="0.03"/>
          </linearGradient>
        </defs>
        {[0,0.5,1].map((f,i) => (
          <line key={i} x1={PL} x2={PL+iW} y1={PT+iH*(1-f)} y2={PT+iH*(1-f)} stroke="rgba(255,255,255,0.07)" strokeWidth="1"/>
        ))}
        {yTicks.map((v,i) => (
          <text key={i} x={PL-4} y={py(v)+4} textAnchor="end" fontSize="9" fill="#8a8a7a">
            {v >= 1000 ? `${(v/1000).toFixed(1)}k` : Math.round(v)}
          </text>
        ))}
        {xIdxs.map((idx,i) => {
          const d = new Date(points[idx].t);
          return <text key={i} x={px(idx)} y={H-4} textAnchor="middle" fontSize="9" fill="#8a8a7a">{`${d.getMonth()+1}/${d.getDate()}`}</text>;
        })}
        <polygon points={areaPts} fill="url(#flowGrad)"/>
        <polyline points={linePts} fill="none" stroke="#b8d4dc" strokeWidth="2" strokeLinejoin="round"/>
        <circle cx={px(points.length-1)} cy={py(points[points.length-1].v)} r="3" fill="#c8a84b"/>
      </svg>
    </div>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const style = `
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Crimson+Pro:ital,wght@0,300;0,400;0,600;1,300;1,400&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
:root{--water:#2c5f6e;--deep:#1a3a45;--foam:#e8dfc8;--moss:#5a7a4a;--stone:#8a8a7a;--sky:#b8d4dc;--gold:#c8a84b;--red:#e07070;}
body{font-family:'Crimson Pro',serif;background:var(--deep);color:var(--foam);min-height:100vh;}
.app{max-width:430px;margin:0 auto;min-height:100vh;background:var(--deep);position:relative;overflow:hidden;}
.bgbar{position:fixed;top:0;left:50%;transform:translateX(-50%);width:430px;height:200px;background:linear-gradient(180deg,var(--water),var(--deep));z-index:0;pointer-events:none;}
.main{position:absolute;inset:0;overflow-y:auto;transition:transform .3s cubic-bezier(.4,0,.2,1);}
.main.off{transform:translateX(-100%);}
.slide{position:absolute;inset:0;overflow-y:auto;background:var(--deep);transform:translateX(100%);transition:transform .3s cubic-bezier(.4,0,.2,1);z-index:20;}
.slide.on{transform:translateX(0);}
.slide-hdr{display:flex;align-items:center;gap:12px;padding:52px 20px 16px;background:linear-gradient(180deg,var(--water),var(--deep));position:sticky;top:0;z-index:5;}
.back{background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.15);border-radius:10px;padding:8px 12px;color:var(--foam);font-size:14px;cursor:pointer;font-family:'Crimson Pro',serif;}
.slide-title{font-family:'Playfair Display',serif;font-size:20px;color:var(--foam);font-style:italic;}
.hdr{position:relative;z-index:1;padding:44px 24px 16px;text-align:center;}
.title{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:var(--foam);}
.title span{color:var(--gold);font-style:italic;}
.sub{font-size:12px;color:var(--sky);letter-spacing:2.5px;text-transform:uppercase;margin-top:3px;font-weight:300;}
.search-wrap{position:relative;z-index:50;margin:0 16px 4px;}
.search-row{display:flex;gap:8px;}
.search-input{flex:1;background:rgba(0,0,0,0.45);border:1px solid rgba(255,255,255,0.2);border-radius:12px;padding:12px 14px;color:var(--foam);font-family:'Crimson Pro',serif;font-size:15px;outline:none;transition:border .2s;}
.search-input::placeholder{color:var(--stone);}
.search-input:focus{border-color:var(--water);}
.gps-btn{background:rgba(44,95,110,0.6);border:1px solid rgba(255,255,255,0.2);border-radius:12px;padding:0 14px;color:var(--foam);font-size:18px;cursor:pointer;display:flex;align-items:center;transition:background .2s;}
.gps-btn:hover{background:var(--water);}
.gps-btn:disabled{opacity:.4;cursor:not-allowed;}
.sugg-list{position:absolute;top:calc(100% + 6px);left:0;right:54px;background:#1c3a47;border:1px solid rgba(255,255,255,0.18);border-radius:14px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,0.6);z-index:999;}
.sugg{display:flex;align-items:center;gap:10px;padding:12px 14px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,0.06);transition:background .15s;}
.sugg:last-child{border-bottom:none;}
.sugg:hover,.sugg:active{background:rgba(44,95,110,0.5);}
.sugg-label{font-size:14px;color:var(--foam);}
.loc-hint{font-size:11px;color:var(--stone);text-align:center;margin:4px 16px 8px;font-style:italic;position:relative;z-index:1;}
.nav{position:relative;z-index:1;display:flex;margin:0 16px;background:rgba(0,0,0,0.25);border-radius:14px;padding:4px;gap:2px;}
.nb{flex:1;padding:9px 4px;border:none;background:transparent;color:var(--sky);font-family:'Crimson Pro',serif;font-size:11px;cursor:pointer;border-radius:10px;transition:all .2s;display:flex;flex-direction:column;align-items:center;gap:3px;}
.nb .ic{font-size:17px;}
.nb.on{background:var(--water);color:var(--foam);}
.content{position:relative;z-index:1;padding:16px 16px 100px;}
.card{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:18px;padding:18px;margin-bottom:14px;backdrop-filter:blur(8px);}
.ctitle{font-family:'Playfair Display',serif;font-size:16px;color:var(--gold);margin-bottom:12px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.csub{font-size:12px;color:var(--stone);margin-top:-8px;margin-bottom:12px;font-style:italic;}
.rfsh{background:none;border:none;color:var(--sky);font-size:13px;cursor:pointer;padding:0;margin-left:auto;}
.loading{text-align:center;padding:20px;color:var(--stone);font-style:italic;font-size:14px;animation:pulse 1.5s infinite;}
@keyframes pulse{0%,100%{opacity:.4;}50%{opacity:1;}}
.err{background:rgba(150,80,80,0.2);border:1px solid rgba(150,80,80,0.4);border-radius:10px;padding:10px 14px;font-size:13px;color:var(--red);margin-bottom:12px;}
.info-box{background:rgba(44,95,110,0.18);border:1px solid rgba(44,95,110,0.35);border-radius:14px;padding:16px;font-size:14px;color:var(--sky);line-height:1.8;margin-bottom:14px;}
.wx-main{display:flex;align-items:center;justify-content:center;gap:16px;margin-bottom:14px;}
.wx-temp{font-family:'Playfair Display',serif;font-size:52px;color:var(--foam);line-height:1;}
.wx-desc{font-size:15px;color:var(--sky);font-style:italic;margin-top:4px;}
.wx-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.wx-item{background:rgba(0,0,0,0.2);border-radius:12px;padding:12px;text-align:center;}
.wx-val{font-family:'Playfair Display',serif;font-size:17px;color:var(--foam);}
.wx-lbl{font-size:11px;color:var(--stone);letter-spacing:1px;text-transform:uppercase;margin-top:3px;}
.gi{margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,0.06);}
.gi:last-child{border-bottom:none;margin-bottom:0;padding-bottom:0;}
.grow{display:flex;justify-content:space-between;align-items:center;margin-bottom:3px;}
.gname{font-size:13px;color:var(--foam);flex:1;padding-right:8px;line-height:1.3;}
.gval{font-size:12px;color:var(--sky);}
.gbadge{display:inline-block;padding:2px 8px;border-radius:20px;font-size:11px;text-transform:uppercase;white-space:nowrap;}
.gbadge.good{background:rgba(90,122,74,0.4);color:#9cd47a;border:1px solid rgba(90,122,74,0.5);}
.gbadge.fair{background:rgba(200,168,75,0.3);color:var(--gold);border:1px solid rgba(200,168,75,0.4);}
.gbadge.high{background:rgba(150,80,80,0.3);color:var(--red);border:1px solid rgba(150,80,80,0.4);}
.gbadge.low{background:rgba(100,80,50,0.3);color:#c4a06a;border:1px solid rgba(120,100,60,0.4);}
.bar{background:rgba(0,0,0,0.3);border-radius:8px;height:10px;margin:6px 0;overflow:hidden;}
.bar-f{height:100%;background:linear-gradient(90deg,var(--sky),var(--water));border-radius:8px;transition:width .8s;}
.hr{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.05);font-size:14px;}
.hn{color:var(--foam);}.ha{color:var(--gold);font-style:italic;}
.lhdr{display:flex;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,0.08);}
.lttl{font-family:'Playfair Display',serif;font-size:15px;letter-spacing:1.5px;text-transform:uppercase;color:var(--stone);}
.cc{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);border-radius:16px;overflow:hidden;margin-bottom:12px;}
.c-img{width:100%;height:160px;object-fit:cover;display:block;}
.c-ph{width:100%;height:70px;background:rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;font-size:28px;color:var(--stone);}
.cb{padding:14px;}
.csp{font-family:'Playfair Display',serif;font-size:18px;color:var(--foam);font-style:italic;}
.cm{display:flex;gap:12px;margin:6px 0;flex-wrap:wrap;}
.cmi{font-size:13px;color:var(--sky);}
.cff{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px;}
.cfly{background:rgba(44,95,110,0.3);border:1px solid rgba(44,95,110,0.5);border-radius:12px;padding:2px 10px;font-size:12px;color:var(--sky);}
.cgps{font-size:11px;color:var(--stone);margin-top:6px;font-style:italic;}
.empty{text-align:center;padding:48px 24px;color:var(--stone);}
.empty .ei{font-size:48px;margin-bottom:12px;opacity:.5;}
.empty p{font-size:15px;font-style:italic;}
.fab{position:fixed;bottom:28px;right:calc(50% - 215px + 20px);width:58px;height:58px;border-radius:50%;background:linear-gradient(135deg,var(--water),var(--moss));border:none;color:var(--foam);font-size:28px;cursor:pointer;box-shadow:0 4px 20px rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;transition:transform .15s;z-index:10;}
.fab:hover{transform:scale(1.08);}
@media(max-width:430px){.fab{right:20px;}}
.lbl{display:block;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:var(--stone);margin-bottom:5px;}
.inp{width:100%;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.12);border-radius:10px;padding:10px 12px;color:var(--foam);font-family:'Crimson Pro',serif;font-size:15px;outline:none;margin-bottom:12px;transition:border .2s;}
.inp:focus{border-color:var(--water);}
select.inp{-webkit-appearance:none;}
.pbtns{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;}
.pbtn{display:flex;flex-direction:column;align-items:center;gap:8px;padding:20px 8px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.12);border-radius:14px;color:var(--sky);font-family:'Crimson Pro',serif;font-size:14px;cursor:pointer;}
.pbtn:hover{background:rgba(44,95,110,0.35);border-color:var(--water);}
.pbtn .pi{font-size:28px;}
.pw{position:relative;border-radius:14px;overflow:hidden;margin-bottom:10px;}
.p-img{width:100%;height:220px;object-fit:cover;display:block;}
.pov{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(transparent,rgba(0,0,0,0.78));padding:12px;display:flex;flex-direction:column;gap:3px;}
.ptag{font-size:11px;color:var(--sky);}.ttag{font-size:12px;color:var(--foam);font-style:italic;}
.px{position:absolute;top:8px;right:8px;background:rgba(0,0,0,0.65);border:none;color:var(--foam);width:30px;height:30px;border-radius:50%;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;}
.ftags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px;}
.ftag{background:rgba(44,95,110,0.4);border:1px solid var(--water);border-radius:20px;padding:4px 12px;font-size:13px;color:var(--sky);display:flex;align-items:center;gap:6px;}
.ftag button{background:none;border:none;color:var(--stone);cursor:pointer;font-size:14px;line-height:1;padding:0;}
.frow{display:flex;gap:8px;margin-bottom:12px;}
.frow .inp{margin-bottom:0;flex:1;}
.btn{background:var(--water);color:var(--foam);border:none;border-radius:10px;padding:10px 16px;font-family:'Crimson Pro',serif;font-size:14px;cursor:pointer;white-space:nowrap;}
.btn:hover{background:#3a7a8e;}
.btnp{width:100%;padding:15px;font-size:16px;background:linear-gradient(135deg,var(--water),var(--moss));letter-spacing:1px;border-radius:14px;margin-top:4px;}
.hint{font-size:11px;color:var(--stone);margin-bottom:14px;margin-top:-4px;}
.gen{width:100%;padding:14px;background:linear-gradient(135deg,#2c5f6e,#5a7a4a);border:none;border-radius:14px;color:var(--foam);font-family:'Playfair Display',serif;font-size:17px;font-style:italic;cursor:pointer;margin-top:4px;}
.gen:disabled{opacity:.5;cursor:not-allowed;}
.step{display:flex;align-items:center;gap:10px;padding:7px 0;font-size:13px;color:var(--stone);}
.step.done{color:var(--sky);}
.step.active{color:var(--foam);}
.dot{width:8px;height:8px;border-radius:50%;background:var(--stone);flex-shrink:0;}
.step.done .dot{background:var(--moss);}
.step.active .dot{background:var(--gold);animation:pulse 1s infinite;}
.fcgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;}
.fcd{background:rgba(0,0,0,0.2);border-radius:10px;padding:8px 4px;text-align:center;}
.fcd.hi{border:1px solid var(--gold);background:rgba(200,168,75,0.1);}
.fcdn{font-size:10px;color:var(--stone);text-transform:uppercase;letter-spacing:.5px;}
.fcic{font-size:20px;margin:4px 0;}
.fchi{font-family:'Playfair Display',serif;font-size:16px;color:var(--foam);}
.fclo{font-size:12px;color:var(--stone);}
.scard{background:rgba(0,0,0,0.25);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:12px 14px;margin-bottom:8px;}
.sname{font-size:14px;color:var(--foam);font-weight:600;margin-bottom:3px;}
.smeta{font-size:12px;color:var(--stone);display:flex;gap:8px;flex-wrap:wrap;}
.srat{color:var(--gold);}
.rb{background:rgba(0,0,0,0.2);border-left:3px solid var(--water);border-radius:0 10px 10px 0;padding:12px 14px;margin-bottom:10px;}
.rriver{font-family:'Playfair Display',serif;font-size:15px;color:var(--gold);margin-bottom:6px;font-style:italic;}
.rbody{font-size:14px;color:var(--foam);line-height:1.6;}
.rtech{font-size:13px;color:var(--sky);margin-top:6px;font-style:italic;}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;}
.chip{background:rgba(90,122,74,0.3);border:1px solid rgba(90,122,74,0.5);border-radius:20px;padding:3px 12px;font-size:12px;color:#9cd47a;}
.slbl{font-size:12px;color:var(--gold);letter-spacing:1px;text-transform:uppercase;margin:14px 0 6px;}
.divider{border:none;border-top:1px solid rgba(255,255,255,0.07);margin:14px 0;}
.flow-wrap{background:rgba(0,0,0,0.2);border-radius:12px;padding:12px;}
.last-upd{font-size:11px;color:var(--stone);text-align:right;margin-bottom:8px;font-style:italic;}
`;

// ─── Typeahead search component ───────────────────────────────────────────────
function LocationSearch({ onSelect, initialValue = "", placeholder = "Search river, city, or state…" }) {
  const [query, setQuery]     = useState(initialValue);
  const [suggs, setSuggs]     = useState([]);
  const [open, setOpen]       = useState(false);
  const [loading, setLoading] = useState(false);
  const [gpsState, setGpsState] = useState("idle");
  const [gpsMsg, setGpsMsg]   = useState("");
  const debounce = useRef(null);
  const wrap = useRef(null);

  useEffect(() => { if (initialValue) setQuery(initialValue); }, [initialValue]);

  useEffect(() => {
    const fn = e => { if (wrap.current && !wrap.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, []);

  function onChange(val) {
    setQuery(val);
    clearTimeout(debounce.current);
    if (val.trim().length < 2) { setSuggs([]); setOpen(false); return; }
    debounce.current = setTimeout(() => fetchSuggestions(val), 300);
  }

  async function fetchSuggestions(val) {
    setLoading(true);
    try {
      const data = await geocode(val);
      if (data.length) {
        setSuggs(data.slice(0, 6));
        setOpen(true);
      }
    } catch {}
    finally { setLoading(false); }
  }

  function pick(item) {
    const label = cleanLocationLabel(item);
    setQuery(label);
    setSuggs([]); setOpen(false);
    onSelect({ lat: parseFloat(item.lat), lng: parseFloat(item.lon), label });
  }

  function handleGPS() {
    setGpsMsg(""); setGpsState("loading");
    if (!navigator.geolocation) {
      setGpsState("error");
      setGpsMsg("GPS not supported. Please search manually.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async pos => {
        const { latitude: lat, longitude: lng } = pos.coords;
        try {
          const data = await reverseGeocode(lat, lng);
          const a = data.address || {};
          const city = a.city || a.town || a.village || a.county || "";
          const state = a.state || "";
          const label = city ? `${city}, ${state}` : (state || fmtCoord(lat, lng));
          setQuery(label); setGpsState("idle");
          onSelect({ lat, lng, label });
        } catch {
          const label = fmtCoord(lat, lng);
          setQuery(label); setGpsState("idle");
          onSelect({ lat, lng, label });
        }
      },
      err => {
        setGpsState("error");
        setGpsMsg(err.code === 1 ? "Location access denied. Please search manually." : "GPS unavailable. Please search manually.");
      },
      { timeout: 8000, enableHighAccuracy: true }
    );
  }

  return (
    <div ref={wrap} style={{position:"relative"}}>
      <div className="search-row">
        <div style={{position:"relative",flex:1}}>
          <input
            className="search-input"
            placeholder={placeholder}
            value={query}
            onChange={e => onChange(e.target.value)}
            onFocus={() => suggs.length && setOpen(true)}
            autoComplete="off" spellCheck={false}
          />
          {loading && <span style={{position:"absolute",right:10,top:"50%",transform:"translateY(-50%)",color:"var(--sky)",fontSize:13,animation:"pulse 1s infinite"}}>✦</span>}
        </div>
        <button className="gps-btn" onClick={handleGPS} disabled={gpsState==="loading"} title="Use my location">
          {gpsState === "loading" ? "…" : "📍"}
        </button>
      </div>
      {gpsState === "error" && (
        <div style={{marginTop:6,padding:"8px 12px",background:"rgba(150,80,80,0.15)",border:"1px solid rgba(150,80,80,0.3)",borderRadius:10,fontSize:12,color:"var(--red)",lineHeight:1.5}}>
          {gpsMsg}
        </div>
      )}
      {open && suggs.length > 0 && (
        <div className="sugg-list">
          {suggs.map((item, i) => (
            <div key={i} className="sugg" onMouseDown={() => pick(item)}>
              <span style={{fontSize:16}}>{locationIcon(item)}</span>
              <span className="sugg-label">{cleanLocationLabel(item)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Trip Planner ─────────────────────────────────────────────────────────────
function TripPlanner({ defaultLocation }) {
  const [loc, setLoc]   = useState({ label: defaultLocation || "", lat: null, lng: null });
  const [date, setDate] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() + 3);
    return d.toISOString().split("T")[0];
  });
  const [steps, setSteps]     = useState([]);
  const [busy, setBusy]       = useState(false);
  const [error, setError]     = useState(null);
  const [wxData, setWxData]   = useState(null);
  const [flowPoints, setFlowPoints] = useState([]);
  const [flowLabel, setFlowLabel]   = useState("");
  const [gauges, setGauges]   = useState([]);
  const [shops, setShops]     = useState([]);
  const [report, setReport]   = useState(null);

  useEffect(() => { if (defaultLocation) setLoc(l => ({...l, label: defaultLocation})); }, [defaultLocation]);

  function addStep(text, state = "done") {
    setSteps(prev => {
      const n = [...prev];
      if (n.length && n[n.length-1].state === "active") n[n.length-1].state = "done";
      n.push({ text, state });
      return n;
    });
  }

  async function generate() {
    if (!loc.label.trim()) { setError("Please enter a destination."); return; }
    setBusy(true); setError(null); setSteps([]);
    setWxData(null); setFlowPoints([]); setGauges([]); setShops([]); setReport(null);

    try {
      // 1. Geocode if needed
      addStep("Finding location…", "active");
      let lat = loc.lat, lng = loc.lng;
      if (!lat || !lng) {
        const data = await geocode(loc.label);
        if (!data.length) throw new Error("Location not found. Try a more specific search.");
        lat = parseFloat(data[0].lat); lng = parseFloat(data[0].lon);
        setLoc(l => ({...l, lat, lng}));
      }
      addStep(`📍 ${loc.label}`);

      // 2. Weather forecast
      addStep("Fetching 7-day forecast…", "active");
      const wx = await fetchWeather(lat, lng);
      setWxData(wx);
      addStep("Forecast loaded ✓");

      // 3. Stream gauges
      addStep("Loading stream gauge data…", "active");
      const [liveData, histData] = await Promise.all([
        fetchUSGSLive(lat, lng),
        fetchUSGSHistory(lat, lng),
      ]);
      const liveTS = liveData.value?.timeSeries ?? [];
      const parsedGauges = liveTS.map(t => {
        const raw = t.values?.[0]?.value?.[0]?.value;
        const cfs = raw != null ? parseFloat(raw) : null;
        const { label, cls } = cfsLabel(cfs);
        return { name: t.sourceInfo?.siteName ?? "Unknown", cfs, pct: cfs ? Math.min(Math.round((cfs/5000)*100), 100) : 0, label, cls };
      }).filter(s => s.cfs === null || (s.cfs >= 0 && s.cfs < 500000))
        .sort((a,b) => (b.cfs??-1) - (a.cfs??-1)).slice(0,6);
      setGauges(parsedGauges);

      const histTS = histData.value?.timeSeries ?? [];
      if (histTS.length) {
        const best = histTS.sort((a,b) => (b.values?.[0]?.value?.length||0) - (a.values?.[0]?.value?.length||0))[0];
        const pts = (best.values?.[0]?.value ?? []).map(v => ({ t: v.dateTime, v: parseFloat(v.value) })).filter(v => !isNaN(v.v) && v.v >= 0 && v.v < 500000);
        setFlowPoints(pts);
        setFlowLabel(best.sourceInfo?.siteName ?? "");
      }
      addStep(`${parsedGauges.length} stream gauges loaded ✓`);

      // 4. Fly shops via Claude web search
      addStep("Finding top-rated fly shops…", "active");
      try {
        const shopTxt = await askClaude(
          `Search Google for the best fly fishing shops near ${loc.label}. Find shops with high ratings and many reviews. Return ONLY a JSON array (no markdown), top 5 ranked by rating × log(reviews):
[{"name":"Shop Name","rating":4.8,"reviews":245,"specialty":"nymphing, dry fly","address":"City, ST","website":"https://..."}]
Real shops only. JSON array only.`, true
        );
        const data = extractJSON(shopTxt);
        if (Array.isArray(data)) setShops(data.slice(0,5));
      } catch {}
      addStep("Fly shops found ✓");

      // 5. AI fishing report
      addStep("Synthesizing fishing report…", "active");
      const dateStr = new Date(date + "T12:00:00").toLocaleDateString("en-US", { weekday:"long", month:"long", day:"numeric", year:"numeric" });
      const month = new Date(date + "T12:00:00").getMonth();
      const hatchInfo = MONTHLY_HATCHES[month].map(h => `${h.name} (${h.activity})`).join(", ");
      const gaugeSum = parsedGauges.slice(0,3).map(g => `${g.name}: ${g.cfs?.toFixed(0)??"N/A"} CFS (${g.label})`).join("; ") || "No gauge data";

      const rptTxt = await askClaude(
        `Search for current fishing reports for ${loc.label} around ${dateStr}. Check fly shop websites, state fish & wildlife agencies, and fishing forums.

Return ONLY valid JSON (no markdown):
{"overview":"2-3 sentence summary","rivers":[{"name":"River","conditions":"conditions","techniques":"techniques","flies":["Pattern #size","Pattern #size","Pattern #size","Pattern #size"]}],"hatches":"hatch timing","bestTimes":"best times of day","tips":"insider tips","flyBoxEssentials":["Pattern #size","Pattern #size","Pattern #size","Pattern #size","Pattern #size","Pattern #size","Pattern #size","Pattern #size"]}

Stream data: ${gaugeSum}
Seasonal hatches: ${hatchInfo}
Include 2-4 rivers near ${loc.label}. Specific fly sizes. JSON only.`, true, 1200
      );
      const rptData = extractJSON(rptTxt);
      setReport(rptData || { overview: rptTxt, rivers:[], hatches:"", bestTimes:"", tips:"", flyBoxEssentials:[] });
      addStep("Report complete ✓");

    } catch(e) {
      setError(e.message || "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  const tripDay = new Date(date + "T12:00:00");
  const daysFromNow = Math.round((tripDay - new Date()) / 86400000);

  return (
    <div>
      <div className="card">
        <div className="ctitle">🗓 Plan Your Trip</div>
        <label className="lbl">Destination</label>
        <div style={{marginBottom:12}}>
          <LocationSearch placeholder="River, city, or region…" initialValue={loc.label} onSelect={s => setLoc(s)}/>
        </div>
        <label className="lbl">Trip Date</label>
        <input className="inp" type="date" value={date} min={new Date().toISOString().split("T")[0]} onChange={e => setDate(e.target.value)}/>
        {error && <div className="err">{error}</div>}
        <button className="gen" onClick={generate} disabled={busy}>
          {busy ? "Generating…" : "✦ Generate Fishing Report"}
        </button>
      </div>

      {steps.length > 0 && (
        <div className="card">
          {steps.map((s,i) => (
            <div key={i} className={`step ${s.state}`}><div className="dot"/>{s.text}</div>
          ))}
        </div>
      )}

      {wxData?.daily && !busy && (
        <div className="card">
          <div className="ctitle">🌤 7-Day Forecast</div>
          <div className="fcgrid">
            {wxData.daily.time?.slice(0,7).map((d,i) => {
              const dt = new Date(d + "T12:00:00");
              return (
                <div key={i} className={`fcd${i === daysFromNow ? " hi" : ""}`}>
                  <div className="fcdn">{DAY_NAMES[dt.getDay()]}</div>
                  <div className="fcic">{WX_EMOJI[wxData.daily.weather_code?.[i]] || "🌡"}</div>
                  <div className="fchi">{Math.round(wxData.daily.temperature_2m_max?.[i])}°</div>
                  <div className="fclo">{Math.round(wxData.daily.temperature_2m_min?.[i])}°</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {gauges.length > 0 && !busy && (
        <div className="card">
          <div className="ctitle">💧 Stream Gauges</div>
          <div className="csub">Live USGS data near {loc.label}</div>
          {gauges.map((g,i) => (
            <div className="gi" key={i}>
              <div className="grow"><span className="gname">{g.name}</span><span className={`gbadge ${g.cls}`}>{g.label}</span></div>
              <div className="grow"><span className="gval">{g.cfs != null ? `${Number(g.cfs).toLocaleString()} CFS` : "No reading"}</span></div>
              <div className="bar"><div className="bar-f" style={{width:`${g.pct}%`}}/></div>
            </div>
          ))}
        </div>
      )}

      {flowPoints.length > 1 && !busy && (
        <div className="card">
          <div className="ctitle">📈 30-Day Flow History</div>
          <div className="flow-wrap"><FlowChart points={flowPoints} label={flowLabel}/></div>
          <div style={{fontSize:11,color:"var(--stone)",marginTop:6,textAlign:"right",fontStyle:"italic"}}>Source: USGS · CFS</div>
        </div>
      )}

      {shops.length > 0 && !busy && (
        <div className="card">
          <div className="ctitle">🪝 Top Fly Shops</div>
          <div className="csub">Ranked by rating × review count</div>
          {shops.map((s,i) => (
            <div className="scard" key={i}>
              <div className="sname">{i+1}. {s.name}</div>
              <div className="smeta">
                {s.rating && <span className="srat">★ {s.rating}</span>}
                {s.reviews && <span>({Number(s.reviews).toLocaleString()} reviews)</span>}
                {s.address && <span>{s.address}</span>}
              </div>
              {s.specialty && <div style={{fontSize:12,color:"var(--sky)",marginTop:4,fontStyle:"italic"}}>{s.specialty}</div>}
              {s.website && <a href={s.website} target="_blank" rel="noreferrer" style={{fontSize:12,color:"var(--gold)",display:"block",marginTop:4}}>{s.website.replace(/^https?:\/\//,"").split("/")[0]}</a>}
            </div>
          ))}
        </div>
      )}

      {report && !busy && (
        <div className="card">
          <div className="ctitle">🎣 Fishing Report</div>
          <div className="csub">Synthesized from current web reports & local conditions</div>
          <p style={{fontSize:14,color:"var(--foam)",lineHeight:1.65,marginBottom:14}}>{report.overview}</p>
          {report.rivers?.length > 0 && <>
            <div className="divider"/>
            {report.rivers.map((r,i) => (
              <div className="rb" key={i}>
                <div className="rriver">🏞 {r.name}</div>
                <div className="rbody">{r.conditions}</div>
                {r.techniques && <div className="rtech">{r.techniques}</div>}
                {r.flies?.length > 0 && <div className="chips">{r.flies.map((f,j) => <span className="chip" key={j}>🪶 {f}</span>)}</div>}
              </div>
            ))}
          </>}
          {report.hatches && <><div className="slbl">Hatch Activity</div><p style={{fontSize:14,color:"var(--foam)",lineHeight:1.65,marginBottom:14}}>{report.hatches}</p></>}
          {report.bestTimes && <><div className="slbl">Best Times</div><p style={{fontSize:14,color:"var(--foam)",lineHeight:1.65,marginBottom:14}}>{report.bestTimes}</p></>}
          {report.tips && <><div className="slbl">Insider Tips</div><p style={{fontSize:14,color:"var(--foam)",lineHeight:1.65,marginBottom:14}}>{report.tips}</p></>}
          {report.flyBoxEssentials?.length > 0 && <>
            <div className="divider"/>
            <div className="slbl">Fly Box Essentials</div>
            <div className="chips">{report.flyBoxEssentials.map((f,i) => <span className="chip" key={i}>🪶 {f}</span>)}</div>
          </>}
        </div>
      )}
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab]         = useState("conditions");
  const [addOpen, setAddOpen] = useState(false);
  const [loc, setLoc]         = useState(null);
  const [weather, setWeather] = useState(null);
  const [wxLoading, setWxLoading] = useState(false);
  const [wxError, setWxError]     = useState(null);
  const [gauges, setGauges]       = useState([]);
  const [gaugeLoading, setGaugeLoading] = useState(false);
  const [gaugeError, setGaugeError]     = useState(null);
  const [lastUpd, setLastUpd]           = useState(null);

  const [catches, setCatches] = useState([
    { id:1, species:"Brown Trout", length:"18", flies:["Elk Hair Caddis #14","Woolly Bugger"],
      photo:null, gps:"45.7128° N, 111.0429° W", time:"June 12, 2025 · 7:43 AM",
      notes:"Beautiful fish on the second drift near the far bank eddy." }
  ]);
  const blank = { species:"Brown Trout", length:"", flies:[], flyInput:"", notes:"", photo:null, gps:null, time:null };
  const [form, setForm] = useState(blank);
  const camRef = useRef(), galRef = useRef();

  async function loadConditions(newLoc) {
    setLoc(newLoc);
    const { lat, lng } = newLoc;

    setWxLoading(true); setWxError(null);
    try {
      const d = await fetchWeather(lat, lng);
      const c = d.current;
      setWeather({
        temp: Math.round(c.temperature_2m),
        humidity: c.relative_humidity_2m,
        wind: Math.round(c.wind_speed_10m),
        pressure: (c.surface_pressure * 0.02953).toFixed(2),
        uv: Math.round(c.uv_index ?? 0),
        desc: `${WX_EMOJI[c.weather_code] || ""} ${WX_DESC[c.weather_code] || ""}`.trim(),
      });
    } catch { setWxError("Weather unavailable. Check connection."); }
    finally { setWxLoading(false); }

    setGaugeLoading(true); setGaugeError(null); setGauges([]);
    try {
      const d = await fetchUSGSLive(lat, lng);
      const ts = d.value?.timeSeries ?? [];
      if (!ts.length) { setGaugeError("No stream gauges found nearby."); return; }
      const parsed = ts.map(t => {
        const raw = t.values?.[0]?.value?.[0]?.value;
        const cfs = raw != null ? parseFloat(raw) : null;
        const { label, cls } = cfsLabel(cfs);
        return { name: t.sourceInfo?.siteName ?? "Unknown", cfs, pct: cfs ? Math.min(Math.round((cfs/5000)*100),100) : 0, label, cls };
      }).filter(s => s.cfs === null || (s.cfs >= 0 && s.cfs < 500000))
        .sort((a,b) => (b.cfs??-1) - (a.cfs??-1)).slice(0,8);
      setGauges(parsed);
      setLastUpd(new Date().toLocaleTimeString([], { hour:"2-digit", minute:"2-digit" }));
    } catch { setGaugeError("Could not load stream data."); }
    finally { setGaugeLoading(false); }
  }

  function handlePhoto(e) {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const now = new Date();
      const t = now.toLocaleString("en-US", { month:"long", day:"numeric", year:"numeric", hour:"numeric", minute:"2-digit", hour12:true });
      const g = loc ? fmtCoord(loc.lat, loc.lng) : "Location unavailable";
      setForm(f => ({...f, photo: ev.target.result, gps: g, time: t}));
    };
    reader.readAsDataURL(file); e.target.value = "";
  }

  function addFly() { if (!form.flyInput.trim()) return; setForm(f => ({...f, flies:[...f.flies, f.flyInput.trim()], flyInput:""})); }
  function removeFly(i) { setForm(f => ({...f, flies: f.flies.filter((_,j) => j!==i)})); }
  function submitCatch() {
    const now = new Date();
    const t = form.time || now.toLocaleString("en-US", { month:"long", day:"numeric", year:"numeric", hour:"numeric", minute:"2-digit", hour12:true });
    setCatches(c => [{id:Date.now(), species:form.species, length:form.length, flies:[...form.flies], photo:form.photo, gps:form.gps||"Location not recorded", time:t, notes:form.notes}, ...c]);
    setForm(blank); setAddOpen(false);
  }

  const hatches = MONTHLY_HATCHES[new Date().getMonth()];

  return (
    <>
      <style>{style}</style>
      <input ref={camRef} type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={handlePhoto}/>
      <input ref={galRef} type="file" accept="image/*" style={{display:"none"}} onChange={handlePhoto}/>

      <div className="app">
        <div className="bgbar"/>

        <div className={`main${addOpen ? " off" : ""}`}>
          <div className="hdr">
            <div className="title">Tight <span>Lines</span></div>
            <div className="sub">Fly Fishing Journal</div>
          </div>

          <div className="search-wrap">
            <LocationSearch
              placeholder="Search river, city, or state…"
              initialValue={loc?.label || ""}
              onSelect={loadConditions}
            />
          </div>
          <div className="loc-hint">
            {loc ? `📌 ${loc.label}` : "Type a location · suggestions appear as you type · 📍 for GPS"}
          </div>

          <div className="nav">
            {[{id:"conditions",icon:"🌤",label:"Conditions"},{id:"log",icon:"🐟",label:"Catch Log"},{id:"plan",icon:"🗓",label:"Plan Trip"}].map(t => (
              <button key={t.id} className={`nb${tab===t.id?" on":""}`} onClick={() => setTab(t.id)}>
                <span className="ic">{t.icon}</span>{t.label}
              </button>
            ))}
          </div>

          <div className="content">
            {tab === "conditions" && <>
              {!loc && (
                <div className="info-box">
                  🔍 <strong>Type a location above</strong> to load live weather and stream conditions.<br/><br/>
                  Try: <em>"Boulder, CO"</em> · <em>"Madison River, MT"</em> · <em>"Deschutes River, OR"</em>
                </div>
              )}
              {loc && <>
                <div className="card">
                  <div className="ctitle">🌡 Current Weather
                    <button className="rfsh" onClick={() => loadConditions(loc)}>↻ Refresh</button>
                  </div>
                  {wxLoading && <div className="loading">Fetching weather…</div>}
                  {wxError && <div className="err">{wxError}</div>}
                  {weather && !wxLoading && <>
                    <div className="wx-main"><div>
                      <div className="wx-temp">{weather.temp}°F</div>
                      <div className="wx-desc">{weather.desc}</div>
                    </div></div>
                    <div className="wx-grid">
                      {[["💨",`${weather.wind} mph`,"Wind"],["💧",`${weather.humidity}%`,"Humidity"],["☀️",String(weather.uv),"UV Index"],["🔵",`${weather.pressure} in`,"Pressure"]].map(([ic,val,lbl]) => (
                        <div className="wx-item" key={lbl}><div className="wx-val">{ic} {val}</div><div className="wx-lbl">{lbl}</div></div>
                      ))}
                    </div>
                  </>}
                </div>
                <div className="card">
                  <div className="ctitle">💧 Nearby Stream Gauges
                    <button className="rfsh" onClick={() => loadConditions(loc)}>↻</button>
                  </div>
                  <div className="csub">Live USGS · ~55 mi radius{lastUpd && ` · Updated ${lastUpd}`}</div>
                  {gaugeLoading && <div className="loading">Loading gauges…</div>}
                  {gaugeError && !gaugeLoading && <div className="err">{gaugeError}</div>}
                  {!gaugeLoading && gauges.map((g,i) => (
                    <div className="gi" key={i}>
                      <div className="grow"><span className="gname">{g.name}</span><span className={`gbadge ${g.cls}`}>{g.label}</span></div>
                      <div className="grow"><span className="gval">{g.cfs != null ? `${Number(g.cfs).toLocaleString()} CFS` : "No reading"}</span></div>
                      <div className="bar"><div className="bar-f" style={{width:`${g.pct}%`}}/></div>
                    </div>
                  ))}
                </div>
              </>}
              <div className="card">
                <div className="ctitle">🪲 This Month's Hatches</div>
                {hatches.map(h => <div className="hr" key={h.name}><span className="hn">{h.name}</span><span className="ha">{h.activity}</span></div>)}
              </div>
            </>}

            {tab === "log" && <>
              <div className="lhdr"><span className="lttl">My Catches · {catches.length} fish</span></div>
              {catches.length === 0 && <div className="empty"><div className="ei">🎣</div><p>No catches yet.<br/>Tap + to record your first!</p></div>}
              {catches.map(c => (
                <div className="cc" key={c.id}>
                  {c.photo ? <img src={c.photo} className="c-img" alt="catch"/> : <div className="c-ph">🐟</div>}
                  <div className="cb">
                    <div className="csp">{c.species}</div>
                    <div className="cm">
                      {c.length && <span className="cmi">📏 {c.length}"</span>}
                      <span className="cmi">🕐 {c.time}</span>
                    </div>
                    {c.flies.length > 0 && <div className="cff">{c.flies.map((f,i) => <span className="cfly" key={i}>🪶 {f}</span>)}</div>}
                    {c.notes && <p style={{fontSize:13,color:"var(--sky)",marginTop:8,fontStyle:"italic"}}>{c.notes}</p>}
                    <div className="cgps">📍 {c.gps}</div>
                  </div>
                </div>
              ))}
            </>}

            {tab === "plan" && <TripPlanner defaultLocation={loc?.label || ""}/>}
          </div>

          {tab === "log" && <button className="fab" onClick={() => { setForm(blank); setAddOpen(true); }}>＋</button>}
        </div>

        <div className={`slide${addOpen ? " on" : ""}`}>
          <div className="slide-hdr">
            <button className="back" onClick={() => setAddOpen(false)}>← Back</button>
            <span className="slide-title">Record a Catch</span>
          </div>
          <div style={{padding:"20px 16px 48px"}}>
            <label className="lbl">Photo</label>
            {form.photo ? (
              <div className="pw">
                <img src={form.photo} className="p-img" alt="catch"/>
                <div className="pov">
                  {form.gps && <span className="ptag">📍 {form.gps}</span>}
                  {form.time && <span className="ttag">{form.time}</span>}
                </div>
                <button className="px" onClick={() => setForm(f=>({...f,photo:null,gps:null,time:null}))}>✕</button>
              </div>
            ) : (
              <div className="pbtns">
                <button className="pbtn" onClick={() => camRef.current.click()}><span className="pi">📷</span>Take Photo</button>
                <button className="pbtn" onClick={() => galRef.current.click()}><span className="pi">🖼️</span>Choose from Library</button>
              </div>
            )}
            <p className="hint">GPS & timestamp auto-recorded with your photo.</p>
            <label className="lbl">Species</label>
            <select className="inp" value={form.species} onChange={e => setForm(f=>({...f,species:e.target.value}))}>
              {SPECIES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <label className="lbl">Length (inches)</label>
            <input className="inp" type="number" placeholder="e.g. 18" value={form.length} onChange={e => setForm(f=>({...f,length:e.target.value}))}/>
            <label className="lbl">Flies Used</label>
            <div className="ftags">{form.flies.map((fly,i) => <div className="ftag" key={i}>🪶 {fly}<button onClick={() => removeFly(i)}>×</button></div>)}</div>
            <div className="frow">
              <input className="inp" placeholder="e.g. Elk Hair Caddis #14" value={form.flyInput}
                onChange={e => setForm(f=>({...f,flyInput:e.target.value}))} onKeyDown={e => e.key==="Enter"&&addFly()}/>
              <button className="btn" onClick={addFly}>Add</button>
            </div>
            <label className="lbl">Notes</label>
            <textarea className="inp" rows={4} style={{resize:"none"}} placeholder="Where, how, conditions…"
              value={form.notes} onChange={e => setForm(f=>({...f,notes:e.target.value}))}/>
            <button className="btn btnp" onClick={submitCatch}>🐟 Save to Log</button>
          </div>
        </div>
      </div>
    </>
  );
}
